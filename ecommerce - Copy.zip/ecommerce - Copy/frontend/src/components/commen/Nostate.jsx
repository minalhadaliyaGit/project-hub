import React from 'react'

const Nostate = ({text= 'Records not Found'}) => {
  return (
    
    <div className='text-center py-5'>{text}</div>
  )
}

export default Nostate