import Hero from './Hero';
import LatestProducts from './LatestProducts';
import FeatureProducts from './FeatureProducts';
import Layout from './Layout';

const Home = () => {
    return (
        <>
        <Layout>
            <Hero />
            <LatestProducts />
            <FeatureProducts />
        </Layout>
           
        </>
    )
}

export default Home