// import { createContext, useState } from "react";

// export const AdminAuthContext = createContext;

// export const AdminAuthProvider = ({children}) => {
//     const adminInfo = localStorage.getItem('adminInfo');
//     const [user,setUser] = useState(adminInfo);

//     const login = (user) => {
//         setUser(user)
//     }

//     const logout = () => {
//         localStorage.removeItem('adminInfo');
//         setUser(null)
//     }

//     return <AdminAuthContext.Provider value={{
//         user,
//         login,
//         logout
//     }}>
//                 {children}
//          </AdminAuthContext.Provider>
// }


import { createContext, useState } from "react";

export const AdminAuthContext = createContext(null);

export const AdminAuthProvider = ({ children }) => {

  const [user, setUser] = useState(
    () => JSON.parse(localStorage.getItem("adminInfo") || "null")
  );

  const login = (admin) => setUser(admin);

  const logout = () => {
    localStorage.removeItem("adminInfo");
    setUser(null);
  };

  return (
    <AdminAuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AdminAuthContext.Provider>
  );
};
