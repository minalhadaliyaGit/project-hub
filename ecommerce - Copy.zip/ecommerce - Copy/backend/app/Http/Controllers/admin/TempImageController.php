<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\TempImage;
use Intervention\Image\ImageManager;

//use Intervention\Image\Drivers\Imagick\Driver;

class TempImageController extends Controller
{
    //
    public function store(Request $request){
        $validator = Validator::make($request->all(),[
            'image' => 'required|image|mimes:jpg,jpeg,png,gif'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'errors' => $validator->errors()
            ], 400);
        }

        $tempImage = new TempImage();
        $tempImage->name = 'Dummy Name';
        $tempImage->save();

        $image = $request->file('image');
        $imageName = time().'.'.$image->extension();
        $image->move(public_path('upload/temp'),$imageName);

        $tempImage->name = $imageName;
        $tempImage->save();

        //$manager = new ImageManager(Driver::class);
        //$img = $manager->read(public_path('upload/temp'.$imageName));
        //$img->coverDown(400, 450);
        //$img = save(public_path('upload/temp/'.$tempImage->name));
        //$img = save(public_path('upload/temp/'.$imageName));

        

        return response()->json([
                    'status' => 200,
                    'message' => 'image hase been uploaded successfully',
                    'data' => $tempImage
                ], 200);

    }
}

